#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Created on Tue Feb 26 02:02:03 2019
@author: mason
"""

''' import libraries '''
import time
import numpy as np
import rospy
from geometry_msgs.msg import PoseStamped

import sys
import signal

def signal_handler(signal, frame): # ctrl + c -> exit program
        print('You pressed Ctrl+C!')
        sys.exit(0)
signal.signal(signal.SIGINT, signal_handler)


''' class '''
class fusion():
    def __init__(self):
        rospy.init_node('robot_controller', anonymous=True)
        self.vins_pos_sub = rospy.Subscriber('/vins_vision', PoseStamped, self.vins_callback)
        self.t265_pos_sub = rospy.Subscriber('/t265_vision', PoseStamped, self.t265_callback)
        self.vision_pose_pub = rospy.Publisher('/mavros/vision_pose/pose', PoseStamped, queue_size=20)
        self.t_c=0
        self.v_c=0
        self.rate = rospy.Rate(25)


    def vins_callback(self, msg):
        self.v_pose=msg
        self.v_c=1
        if self.v_c==1 and self.t_c==1:
            vision_pose = PoseStamped()
            vision_pose.pose.position.x = 0.5*self.v_pose.pose.position.x + 0.5*self.t_pose.pose.position.x
            vision_pose.pose.position.y = 0.5*self.v_pose.pose.position.y + 0.5*self.t_pose.pose.position.y
            vision_pose.pose.position.z = 0.5*self.v_pose.pose.position.z + 0.5*self.t_pose.pose.position.z
            vision_pose.pose.orientation = self.t_pose.pose.orientation
            vision_pose.header.stamp = rospy.Time.now()
            vision_pose.header.frame_id = "map"
            self.vision_pose_pub.publish(vision_pose)

    def t265_callback(self, msg):
        self.t_pose=msg
        self.t_c=1

fusing = fusion()

''' main '''
if __name__ == '__main__':
    while 1:
        try:
            fusing.rate.sleep()
        except (rospy.ROSInterruptException, SystemExit, KeyboardInterrupt) :
            sys.exit(0)
