#include <ros/ros.h>
#include <iostream>
#include <stdio.h>
#include <string.h>

#include <math.h>

#include <geometry_msgs/PoseStamped.h>
#include <tf2_msgs/TFMessage.h>
#include <tf/LinearMath/Quaternion.h> // to Quaternion_to_euler
#include <tf/LinearMath/Matrix3x3.h> // to Quaternion_to_euler
//#include <Eigen/Eigen>
//#include <tf_conversions/tf_eigen.h> // tf::matrixEigenToTF(const Eigen::Matrix3d &e, tf::Matrix3x3 &t), tf::matrixTFToEigen (const tf::Matrix3x3 &t, Eigen::Matrix3d &e)

#include <signal.h>
void signal_handler(sig_atomic_t s) {
  std::cout << "You pressed Ctrl + C, exiting" << std::endl;
  exit(1);
}

using namespace std;

class URL_tf{
  public:
    ros::NodeHandle nh;
    ros::Subscriber subb;
    ros::Publisher pubb;
    tf::Matrix3x3 cam_t_body;
    tf::Matrix3x3 map_t_body;
    geometry_msgs::PoseStamped pub_pose;
    string output_topic;
    int counter=0;

    void tf_cb(const tf2_msgs::TFMessage::ConstPtr& msg);

    URL_tf(ros::NodeHandle& n) : nh(n){
      nh.param<std::string>("/output_topic", output_topic, "/mavros/vision_pose/pose");
      pubb = nh.advertise<geometry_msgs::PoseStamped>(output_topic, 20);
      subb = nh.subscribe<tf2_msgs::TFMessage> ("/tf", 20,  &URL_tf::tf_cb, this);

      pub_pose.header.frame_id = "map";
      ROS_WARN("URL tf_and_vision package's tf_node, Starting node...");
    }
};

void URL_tf::tf_cb(const tf2_msgs::TFMessage::ConstPtr& msg)
{
  for (int l=0; l < msg->transforms.size(); l++){
    if (msg->transforms[l].header.frame_id=="t265_odom_frame" && msg->transforms[l].child_frame_id=="t265_pose_frame"){

      counter++;
      if (counter==1){
          tf::Quaternion q(msg->transforms[l].transform.rotation.x, msg->transforms[l].transform.rotation.y, msg->transforms[l].transform.rotation.z, msg->transforms[l].transform.rotation.w);
          tf::Matrix3x3 m(q);
          double t_r, t_p, t_y;
          m.getRPY(t_r, t_p, t_y);
          ROS_WARN("initial rpy: %.1f %.1f %.1f", t_r*180.0/M_PI, t_p*180.0/M_PI, t_y*180.0/M_PI);
          cam_t_body = m.inverse();
          cam_t_body.getRotation(q);
          ROS_WARN("initial quaternion of cam_t_body: %.2f %.2f %.2f %.2f", q.getX(), q.getY(), q.getZ(), q.getW());
      }

      if (counter%5==0){
          tf::Quaternion q2(msg->transforms[l].transform.rotation.x, msg->transforms[l].transform.rotation.y, msg->transforms[l].transform.rotation.z, msg->transforms[l].transform.rotation.w);
          tf::Matrix3x3 cam_frame_t_cam(q2);

    //      map_t_cam = body_t_cam * cam_frame_t_cam;   ============>>> WRONG!!!
          map_t_body = cam_frame_t_cam * cam_t_body; // IMPORTANT!!!!! 
          // map = cam_fram = Global frame, t265 odom is already in global frame!!!
          // MOST NOT transform global frame (cam_frame) but MOST transform local result!!!!

          tf::Quaternion q3;
          map_t_body.getRotation(q3);

          pub_pose.header.stamp = ros::Time::now(); // important
          pub_pose.pose.position.x = msg->transforms[l].transform.translation.x;
          pub_pose.pose.position.y = msg->transforms[l].transform.translation.y;
          pub_pose.pose.position.z = msg->transforms[l].transform.translation.z;
          pub_pose.pose.orientation.x = q3.getX();
          pub_pose.pose.orientation.y = q3.getY();
          pub_pose.pose.orientation.z = q3.getZ();
          pub_pose.pose.orientation.w = q3.getW();
          pubb.publish(pub_pose);

//          counter=0;
      }
    }
  }
}




int main(int argc, char **argv)
{


  ros::init(argc, argv, "URL_tf_package");
  ros::NodeHandle n("~");

  URL_tf url_tf(n);

  signal(SIGINT, signal_handler);

  ros::spin();

  return 0;
}
