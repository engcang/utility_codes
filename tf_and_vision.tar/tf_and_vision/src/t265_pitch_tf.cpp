#include <ros/ros.h>
#include <iostream>
#include <stdio.h>
#include <string.h>

#include <math.h>
#include <Eigen/Eigen>

#include <geometry_msgs/PoseStamped.h>
#include <tf2_msgs/TFMessage.h>
#include <tf/LinearMath/Quaternion.h> // to Quaternion_to_euler
#include <tf/LinearMath/Matrix3x3.h> // to Quaternion_to_euler

#include <signal.h>
void signal_handler(sig_atomic_t s) {
  std::cout << "You pressed Ctrl + C, exiting" << std::endl;
  exit(1);
}

using namespace std;
using namespace Eigen;

class URL_tf{
  public:
    ros::NodeHandle nh;
    ros::Subscriber subb;
    ros::Publisher pubb;
    Matrix4f cam_t_body = Matrix4f::Identity();
    Matrix4f map_t_body = Matrix4f::Identity();
    Matrix4f cam_frame_t_cam = Matrix4f::Identity();
    geometry_msgs::PoseStamped pub_pose;
    string output_topic;
    int counter=0;

    void tf_cb(const tf2_msgs::TFMessage::ConstPtr& msg);

    URL_tf(ros::NodeHandle& n) : nh(n){
      nh.param<std::string>("/output_topic", output_topic, "/mavros/vision_pose/pose");
      pubb = nh.advertise<geometry_msgs::PoseStamped>(output_topic, 20);
      subb = nh.subscribe<tf2_msgs::TFMessage> ("/tf", 20,  &URL_tf::tf_cb, this);

      pub_pose.header.frame_id = "map";

//      tf::Quaternion q(0.0, 0.3826834, 0.0, 0.9238795);
//      tf::Quaternion q(0.0, -0.3826834, 0.0, 0.9238795);
      tf::Quaternion q(0.0, 0.0, 0.0, 1.0);
      tf::Matrix3x3 m(q);
      cam_t_body(0,0) = m[0][0];
      cam_t_body(0,1) = m[0][1];
      cam_t_body(0,2) = m[0][2];
      cam_t_body(1,0) = m[1][0];
      cam_t_body(1,1) = m[1][1];
      cam_t_body(1,2) = m[1][2];
      cam_t_body(2,0) = m[2][0];
      cam_t_body(2,1) = m[2][1];
      cam_t_body(2,2) = m[2][2];
      cam_t_body(0,3) = -0.2;
      cam_t_body(1,3) = 0.0;
      cam_t_body(2,3) = 0.03;
//      cam_t_body(0,3) = 0.0795;
//      cam_t_body(1,3) = 0.0465 - 0.032;
//      cam_t_body(2,3) = 0.017;
      cam_t_body(3,0) = 0.0;
      cam_t_body(3,1) = 0.0;
      cam_t_body(3,2) = 0.0;
      cam_t_body(3,3) = 1.0;
//      cam_t_body(0,0) = 0.03726188;
//      cam_t_body(0,1) = 0.04472023;
//      cam_t_body(0,2) = 0.99830439;
//      cam_t_body(1,0) = -0.99924661;
//      cam_t_body(1,1) = 0.0125162;
//      cam_t_body(1,2) = 0.03673637;
//      cam_t_body(2,0) = -0.01085212;
//      cam_t_body(2,1) = -0.99892114;
//      cam_t_body(2,2) = 0.04515291;
//      cam_t_body(0,3) = 0.0795457;
//      cam_t_body(1,3) = 0.04649799;
//      cam_t_body(2,3) = 0.01705269;
//      cam_t_body(3,3) = 1.0;
      ROS_WARN("URL tf_and_vision package's tf_node, Starting node...");
    }
};

void URL_tf::tf_cb(const tf2_msgs::TFMessage::ConstPtr& msg)
{
  for (int l=0; l < msg->transforms.size(); l++){
    if (msg->transforms[l].header.frame_id=="camera_odom_frame" && msg->transforms[l].child_frame_id=="camera_pose_frame"){

      counter++;
      if (counter%5==0){
          tf::Quaternion q2(msg->transforms[l].transform.rotation.x, msg->transforms[l].transform.rotation.y, msg->transforms[l].transform.rotation.z, msg->transforms[l].transform.rotation.w);
          tf::Matrix3x3 m2(q2);
          cam_frame_t_cam(0,0) = m2[0][0];
          cam_frame_t_cam(0,1) = m2[0][1];
          cam_frame_t_cam(0,2) = m2[0][2];
          cam_frame_t_cam(1,0) = m2[1][0];
          cam_frame_t_cam(1,1) = m2[1][1];
          cam_frame_t_cam(1,2) = m2[1][2];
          cam_frame_t_cam(2,0) = m2[2][0];
          cam_frame_t_cam(2,1) = m2[2][1];
          cam_frame_t_cam(2,2) = m2[2][2];

          cam_frame_t_cam(0,3) = msg->transforms[l].transform.translation.x;
          cam_frame_t_cam(1,3) = msg->transforms[l].transform.translation.y;
          cam_frame_t_cam(2,3) = msg->transforms[l].transform.translation.z;	
          cam_frame_t_cam(3,3) = 1.0;

//          cam_frame_t_cam(0,3) = 0.0;
//          cam_frame_t_cam(1,3) = 0.0;
//          cam_frame_t_cam(2,3) = 0.0;	
//          cam_frame_t_cam(3,3) = 1.0;

    //      map_t_cam = body_t_cam * cam_frame_t_cam;   ============>>> WRONG!!!

          //map_t_body = cam_frame_t_cam * cam_t_body; // IMPORTANT!!!!! 
          // map = cam_fram = Global frame, t265 odom is already in global frame!!!
          // MOST NOT transform global frame (cam_frame) but MOST transform local result!!!!

          Matrix3f temp_m = Matrix3f::Identity();
          temp_m(0,0) = m2[0][0];
          temp_m(0,1) = m2[0][1];
          temp_m(0,2) = m2[0][2];
          temp_m(1,0) = m2[1][0];
          temp_m(1,1) = m2[1][1];
          temp_m(1,2) = m2[1][2];
          temp_m(2,0) = m2[2][0];
          temp_m(2,1) = m2[2][1];
          temp_m(2,2) = m2[2][2];
          
          map_t_body.block(0,0,3,3) = cam_frame_t_cam.block(0,0,3,3);
          map_t_body.block(0,3,3,1) = cam_frame_t_cam.block(0,3,3,1) + cam_frame_t_cam.block(0,0,3,3) * cam_t_body.block(0,3,3,1);
          
          tf::Matrix3x3 m3;
          m3[0][0] = map_t_body(0,0);
          m3[0][1] = map_t_body(0,1);
          m3[0][2] = map_t_body(0,2);
          m3[1][0] = map_t_body(1,0);
          m3[1][1] = map_t_body(1,1);
          m3[1][2] = map_t_body(1,2);
          m3[2][0] = map_t_body(2,0);
          m3[2][1] = map_t_body(2,1);
          m3[2][2] = map_t_body(2,2);

          tf::Quaternion q3;
          m3.getRotation(q3);

          pub_pose.header.stamp = ros::Time::now(); // important
          pub_pose.pose.position.x = map_t_body(0,3);
          pub_pose.pose.position.y = map_t_body(1,3);
          pub_pose.pose.position.z = map_t_body(2,3);

//          pub_pose.pose.position.x = msg->transforms[l].transform.translation.x+0.1;
//          pub_pose.pose.position.y = msg->transforms[l].transform.translation.y;
//          pub_pose.pose.position.z = msg->transforms[l].transform.translation.z-0.03;
          pub_pose.pose.orientation.x = q3.getX();
          pub_pose.pose.orientation.y = q3.getY();
          pub_pose.pose.orientation.z = q3.getZ();
          pub_pose.pose.orientation.w = q3.getW();
          pubb.publish(pub_pose);

          counter=0;
      }
    }
  }
}




int main(int argc, char **argv)
{


  ros::init(argc, argv, "URL_tf_package");
  ros::NodeHandle n("~");

  URL_tf url_tf(n);

  signal(SIGINT, signal_handler);

  ros::spin();

  return 0;
}
